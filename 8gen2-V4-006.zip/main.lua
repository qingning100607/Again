API_VERSION = 4

local POLICY_CONFIG = {
    -------------------------------------------
    -- 米哈游系
    ["com.miHoYo.hkrpg"] = { -- 崩坏：星穹铁道
        { type = "abs", args = {7, 864000, 2092000} }
    },
    ["Yuanshen"] = { -- 原神通用配置
        { type = "abs", args = {7, 1200000, 2400000} },
        { type = "abs", args = {3, 1000000, 2000000} }
    },
    ["com.miHoYo.Yuanshen"] = "Yuanshen",
    ["com.miHoYo.ys.bilibili"] = "Yuanshen",
    ["com.miHoYo.GenshinImpact"] = "Yuanshen",
    ["com.miHoYo.Nap"] = { -- 绝区零
        { type = "abs", args = {3, 726000, 1286000} },
        { type = "abs", args = {7, 864000, 2726000} }
    },

    -------------------------------------------
    -- 二次元/策略类
    ["com.hypergryph.arknights"] = { -- 明日方舟
        { type = "abs", args = {7, 864000, 2342000} }
    },
    ["com.kurogame.mingchao"] = { -- 鸣潮
        { type = "abs", args = {7, 864000, 2342000} }
    },
    ["azurlane"] = { -- 碧蓝航线通用配置
        { type = "abs", args = {3, 499000, 1056000} },
        { type = "abs", args = {7, 864000, 2227000} }
    },
    ["com.bilibili.azurlane"] = "azurlane",
    ["com.YoStarJP.AzurLane"] = "azurlane",
    ["com.kurogame.haru.hero"] = { -- 战双帕弥什
        { type = "abs", args = {3, 844000, 2457000} }
    },

    -------------------------------------------
    -- 射击/动作类
    ["com.netease.l22"] = { -- 永劫无间
        { type = "abs", args = {7, 864000, 2342000} }
    },
    ["com.tencent.tmgp.dfm"] = { -- 三角洲行动（修复此处语法）
        { type = "abs", args = {3, 844000, 2457000} }
    },
    ["uam"] = { -- 暗区突围通用配置
        { type = "abs", args = {3, 844000, 1785000} },
        { type = "abs", args = {7, 864000, 2592000} }
    },
    ["com.tencent.mf.uam"] = "uam",
    ["com.proximabeta.mf.uamo"] = "uam",
    ["com.tencent.tmgp.pubgmhd"] = { -- 和平精英
        { type = "abs", args = {7, 864000, 2956000} },
        { type = "rel", args = {3, 7, -1200000, -1150000} },
        { type = "rel", args = {0, 7, -1700000, -1500000} }
    },
    ["com.tencent.tmgp.cf"] = { -- 穿越火线
        { type = "abs", args = {3, 844000, 2188000} }
    },
    ["com.netease.yhtj"] = { -- 萤火突击
        { type = "abs", args = {3, 844000, 2203000} },
        { type = "abs", args = {7, 864000, 2187000} }
    }, 
    ["pubgm"] = { -- PUBG通用配置
        { type = "abs", args = {7, 864000, 1843000} }
    },
    ["com.tencent.pubgm"] = "pubgm",
    ["com.pubg.krmobile"] = "pubgm",
    ["com.tencent.ig"] = "pubgm",

    -------------------------------------------
    -- 网易系
    ["com.netease.nshm"] = { -- 逆水寒
        { type = "abs", args = {3, 844000, 2342000} },
        { type = "abs", args = {7, 864000, 2592000} }
    },
    ["com.netease.yyslscn"] = { -- 燕云十六声
        { type = "abs", args = {3, 844000, 1103000} },
        { type = "abs", args = {7, 864000, 1387000} }
    },
    ["com.netease.sky"] = { -- 光遇
        { type = "abs", args = {7, 800000, 2200000} },
        { type = "abs", args = {3, 600000, 700000} }
    },
    ["dwrg"] = { -- 第五人格通用配置
        { type = "abs", args = {3, 499000, 1500000} }
    },
    ["com.netease.dwrg"] = "dwrg",
    ["com.tencent.tmgp.dwrg"] = "dwrg",

    -------------------------------------------
    -- MOBA/竞技类
    ["com.tencent.jkchess"] = { -- 金铲铲之战
        { type = "abs", args = {3, 844000, 2457000} }
    },

    -------------------------------------------
    -- 其他游戏
    ["com.tencent.KiHan"] = { -- 火影忍者手游
        { type = "abs", args = {7, 864000, 1400000} },
        { type = "abs", args = {3, 499000, 2100000} }
    },   
    ["com.tencent.nfsonline"] = { -- 极品飞车
        { type = "abs", args = {7, 900000, 2200000} }
    },
    ["com.tencent.tmgp.speedmobile"] = { -- QQ飞车手游
        { type = "abs", args = {3, 844000, 1785000} }
    },
    ["com.tencent.tmgp.supercell.brawlstars"] = { -- 荒野乱斗
        { type = "abs", args = {3, 499000, 1056000} },
        { type = "abs", args = {7, 864000, 2592000} }
    }
}

-- 配置继承处理函数
local function get_policies(pkg)
    local config = POLICY_CONFIG[pkg]
    if not config then return end
    
    local visited = {}
    while type(config) == "string" do
        if visited[config] then break end
        visited[config] = true
        config = POLICY_CONFIG[config]
    end
    return type(config) == "table" and config or nil
end

-- 加载游戏配置
function load_fas(_, pkg)
    local policies = get_policies(pkg)
    if not policies then return end

    for _, policy in ipairs(policies) do
        if policy.type == "abs" then
            set_extra_policy_abs(unpack(policy.args))
        elseif policy.type == "rel" then
            set_extra_policy_rel(unpack(policy.args))
        end
    end
end

-- 卸载配置
function unload_fas()
    for _, policy in ipairs({0, 3, 7}) do
        remove_extra_policy(policy)
    end
end